<?php   
    include('layout/default.php');
?>
<style>
<?php
    include ('styles/blog.css');
    include('styles/style.css');
?>
</style>

<main role="main" class="container">

    <div class="row">

        <div class="col-sm-8 blog-main">

            <?php
                foreach($posts as $post){
                ?>
            <div class="blog-post">
                <h2 class="blog-post-title"><a class = "title" href="/single-post.php"><?php echo($post['title']) ?></a></h2>
                <p class="blog-post-meta"><?php echo($post['created_at']) ?> by <a href="#"><?php echo($post['author']) ?></a></p>

                <p><?php echo($post['body']) ?></p>
                <?php
                    foreach($comments as $comment){
                ?>
                <ul class = "comments">
                    <li><?php echo($comment['author']) ?> commented:</li>
                    <p class="blog-post-comment"><?php echo($comment['text']) ?></p>

                </ul>
                <?php
                }
                ?>
            </div>
            <?php
            }
            ?>
       
        </div>
        <?php   
        include_once('layout/sidebar.php');
        ?>
      
     </div>
</main>

<?php
include('layout/footer.php');
?>